const start = require("./server");

start();
