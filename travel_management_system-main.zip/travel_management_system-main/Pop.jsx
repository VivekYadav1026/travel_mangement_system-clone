//import { useState } from "react";
import './App.css';
import { Login } from "./components/login/Login";


function App() {

      // for popup 


  return (
    <div className="App" >

    </div>
  );
}

export default App;
